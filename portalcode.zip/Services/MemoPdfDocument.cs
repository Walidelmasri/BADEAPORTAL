using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using BADEAPORTAL.Models;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

namespace BADEAPORTAL.Services
{
    // This is the "layout/template" file you're missing.
    // It defines EXACTLY how the memo PDF looks.
    public sealed class MemoPdfDocument : IDocument
    {
        private readonly MemoPdfRequest _request;
        private readonly byte[] _bannerImage;
        private readonly byte[] _footerImage;

        public MemoPdfDocument(MemoPdfRequest request, byte[] bannerImage, byte[] footerImage)
        {
            _request = request ?? throw new ArgumentNullException(nameof(request));
            _bannerImage = bannerImage ?? throw new ArgumentNullException(nameof(bannerImage));
            _footerImage = footerImage ?? throw new ArgumentNullException(nameof(footerImage));
        }

        public DocumentMetadata GetMetadata() => DocumentMetadata.Default;

        public void Compose(IDocumentContainer container)
        {
            container.Page(page =>
            {
                page.Size(PageSizes.A4);

                // Keep margins controlled (banner/footer usually need tighter control)
                page.MarginLeft(45);
                page.MarginRight(45);
                page.MarginTop(28);
                page.MarginBottom(28);

                page.DefaultTextStyle(ts =>
                    ts.FontFamily("Tajawal")
                      .FontSize(11)
                      .FontColor(Colors.Grey.Darken4)
                );

                page.Header().Element(ComposeHeader);
                page.Content().Element(ComposeContent);
                page.Footer().Element(ComposeFooter);
            });
        }

        private void ComposeHeader(IContainer container)
        {
            container.Column(col =>
            {
                // Banner image
                col.Item()
                   .PaddingBottom(10)
                   .Image(_bannerImage)
                   .FitWidth();

                // Title area (subtle)
                col.Item().Row(row =>
                {
                    row.RelativeItem().Text("Memo")
                        .FontSize(18)
                        .SemiBold()
                        .FontColor(Colors.Black);

                    row.ConstantItem(160).AlignRight().Text(_request.CreatedAtUtc.ToString("dd MMM yyyy"))
                        .FontSize(10)
                        .FontColor(Colors.Grey.Darken1);
                });

                col.Item().PaddingTop(6).LineHorizontal(1).LineColor(Colors.Grey.Lighten2);
                col.Item().PaddingTop(10);
            });
        }

        private void ComposeContent(IContainer container)
        {
            container.Column(col =>
            {
                col.Spacing(10);

                // Memo header block
                col.Item().Element(ComposeMemoHeader);

                // Body
                col.Item().PaddingTop(4).Element(body =>
                {
                    body.Column(b =>
                    {
                        b.Spacing(6);

                        foreach (var para in HtmlToParagraphs(_request.BodyHtml))
                        {
                            b.Item().Text(para)
                                .FontSize(11)
                                .LineHeight(1.35f);
                        }
                    });
                });

                // Prepared by (optional)
                col.Item().PaddingTop(14).Row(row =>
                {
                    row.RelativeItem().Text(t =>
                    {
                        t.Span("Prepared by: ").SemiBold();
                        t.Span(_request.CreatedByName);
                    }).FontSize(10).FontColor(Colors.Grey.Darken2);
                });
            });
        }

        private void ComposeMemoHeader(IContainer container)
        {
            container
                .Border(1)
                .BorderColor(Colors.Grey.Lighten2)
                .Background(Colors.Grey.Lighten5)
                .Padding(14)
                .Column(col =>
                {
                    col.Spacing(6);

                    col.Item().Row(r =>
                    {
                        r.RelativeItem().Text(_request.Subject ?? string.Empty)
                            .FontSize(13)
                            .SemiBold()
                            .FontColor(Colors.Black);
                    });

                    col.Item().PaddingTop(4).LineHorizontal(1).LineColor(Colors.Grey.Lighten2);

                    col.Item().PaddingTop(6).Table(table =>
                    {
                        table.ColumnsDefinition(c =>
                        {
                            c.ConstantColumn(90);
                            c.RelativeColumn();
                        });

                        AddRow(table, "To", _request.To);
                        if (!string.IsNullOrWhiteSpace(_request.Through))
                            AddRow(table, "Through", _request.Through!);

                        AddRow(table, "From", _request.From);
                        AddRow(table, "Subject", _request.Subject);
                        AddRow(table, "Classification", _request.Classification);
                    });
                });
        }

        private static void AddRow(TableDescriptor table, string label, string value)
        {
            table.Cell().Element(LabelCell).Text(label);
            table.Cell().Element(ValueCell).Text(value ?? string.Empty);

            static IContainer LabelCell(IContainer c) =>
                c.PaddingVertical(3).TextStyle(ts => ts.SemiBold().FontColor(Colors.Grey.Darken2));

            static IContainer ValueCell(IContainer c) =>
                c.PaddingVertical(3).TextStyle(ts => ts.FontColor(Colors.Black));
        }

        private void ComposeFooter(IContainer container)
        {
            container.Column(col =>
            {
                col.Item().PaddingTop(10).LineHorizontal(1).LineColor(Colors.Grey.Lighten2);

                // Footer image
                col.Item()
                   .PaddingTop(8)
                   .Image(_footerImage)
                   .FitWidth();
            });
        }

        // NOTE: This is NOT a full HTML renderer.
        // It preserves basic paragraph breaks so the output is readable.
        // For "EXACT SAME" as MemoGenerator, we need to port the real renderer from that project.
        private static IEnumerable<string> HtmlToParagraphs(string html)
        {
            if (string.IsNullOrWhiteSpace(html))
                yield break;

            // remove <img> tags
            html = Regex.Replace(html, "<img[^>]*>", "", RegexOptions.IgnoreCase);

            // turn <br>, </p>, </div>, </li> into newlines
            html = Regex.Replace(html, @"<\s*br\s*/?\s*>", "\n", RegexOptions.IgnoreCase);
            html = Regex.Replace(html, @"</\s*(p|div|li)\s*>", "\n", RegexOptions.IgnoreCase);

            // strip the rest of tags
            html = Regex.Replace(html, "<.*?>", string.Empty);

            // decode & normalize
            var text = System.Net.WebUtility.HtmlDecode(html);
            text = text.Replace("\r\n", "\n");

            foreach (var line in text.Split('\n', StringSplitOptions.RemoveEmptyEntries))
            {
                var trimmed = line.Trim();
                if (!string.IsNullOrWhiteSpace(trimmed))
                    yield return trimmed;
            }
        }
    }
}
